import os
import joblib
import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Customer Segmentation", page_icon="🛍️", layout="wide")
st.title("Customer Segmentation Dashboard")
st.write("Enter a customer's purchasing behaviour to predict their K-Means segment.")

MODEL_PATH = "kmeans_model.pkl"
SCALER_PATH = "scaler.pkl"
FEATURES = [
    "MntWines", "MntFruits", "MntMeatProducts", "MntFishProducts",
    "MntSweetProducts", "MntGoldProds", "NumDealsPurchases",
    "NumWebPurchases", "NumCatalogPurchases", "NumStorePurchases",
    "NumWebVisitsMonth"
]
SEGMENTS = {
    0: ("High-Value Multi-Channel Customers", "High spending and strong purchasing activity across multiple channels."),
    1: ("Low-Spend, Low-Purchase Customers", "Lower spending and purchase activity; consider awareness and introductory offers."),
    2: ("High-Value Store & Catalogue Customers", "High-value customers with strong store and catalogue purchasing activity."),
    3: ("Active Online & Deal-Oriented Customers", "More online engagement and deal-oriented purchasing behaviour.")
}

@st.cache_resource
def load_artifacts():
    if not os.path.isfile(MODEL_PATH):
        raise FileNotFoundError(f"Required file not found: {MODEL_PATH}")
    if not os.path.isfile(SCALER_PATH):
        raise FileNotFoundError(f"Required file not found: {SCALER_PATH}")
    return joblib.load(MODEL_PATH), joblib.load(SCALER_PATH)

try:
    model, scaler = load_artifacts()
except Exception as exc:
    st.error("The model could not be loaded. Confirm that kmeans_model.pkl and scaler.pkl are in the repository and compatible with the installed scikit-learn version.")
    st.exception(exc)
    st.stop()

with st.form("customer_input_form"):
    st.subheader("Product spending")
    c1, c2, c3 = st.columns(3)
    with c1:
        wines = st.number_input("Wine spending", min_value=0.0, step=10.0)
        fruits = st.number_input("Fruit spending", min_value=0.0, step=5.0)
    with c2:
        meat = st.number_input("Meat spending", min_value=0.0, step=10.0)
        fish = st.number_input("Fish spending", min_value=0.0, step=5.0)
    with c3:
        sweets = st.number_input("Sweet products spending", min_value=0.0, step=5.0)
        gold = st.number_input("Gold products spending", min_value=0.0, step=5.0)

    st.subheader("Purchase behaviour")
    c4, c5, c6 = st.columns(3)
    with c4:
        deals = st.number_input("Deal purchases", min_value=0, step=1)
        web = st.number_input("Web purchases", min_value=0, step=1)
    with c5:
        catalogue = st.number_input("Catalogue purchases", min_value=0, step=1)
        store = st.number_input("Store purchases", min_value=0, step=1)
    with c6:
        visits = st.number_input("Website visits per month", min_value=0, step=1)
    submitted = st.form_submit_button("Predict customer segment", type="primary")

if submitted:
    values = [wines, fruits, meat, fish, sweets, gold, deals, web, catalogue, store, visits]
    try:
        input_df = pd.DataFrame([values], columns=FEATURES)
        if not np.isfinite(input_df.to_numpy(dtype=float)).all() or (input_df < 0).any().any():
            raise ValueError("Please enter finite, non-negative values for every feature.")
        scaled = scaler.transform(input_df)
        cluster_id = int(model.predict(scaled)[0])
        if cluster_id not in SEGMENTS:
            raise ValueError(f"Unexpected cluster ID returned by the model: {cluster_id}")
        name, description = SEGMENTS[cluster_id]
        st.success("Prediction completed successfully")
        st.metric("Predicted cluster", f"Cluster {cluster_id}")
        st.subheader(name)
        st.write(description)
        with st.expander("View submitted feature values"):
            st.dataframe(input_df, use_container_width=True)
    except Exception as exc:
        st.error("Prediction could not be completed. Check the input values and confirm that the model and scaler files match.")
        st.exception(exc)

st.divider()
st.caption("Customer segments are behavioural groupings produced by the trained K-Means model. They are intended to support analysis, not to make decisions about individuals automatically.")
