# Customer Segmentation with K-Means

## Files
- `app.py`: Streamlit application
- `kmeans_model.pkl`: trained K-Means model (required)
- `scaler.pkl`: fitted feature scaler (required)
- `requirements_final_integrated.txt`: dependencies (rename to `requirements.txt` when replacing the repository's existing file)
- `Customer_Segmentation_Project_Final_Integrated.ipynb`: project notebook with Task 6 tests and Task 7 deployment checklist
- `Testing_Error_Handling.ipynb`: original testing notebook retained for reference

## Run locally
1. Install dependencies from the requirements file.
2. Place the model and scaler files beside `app.py`.
3. Run `streamlit run app.py`.

The supplied model artifacts were saved with scikit-learn 1.7.2, so that version is pinned to reduce compatibility issues. Only load pickle/joblib files from trusted sources.
